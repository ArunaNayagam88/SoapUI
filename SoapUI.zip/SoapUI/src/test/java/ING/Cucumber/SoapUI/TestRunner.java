package ING.Cucumber.SoapUI;

import org.junit.runner.RunWith;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@Cucumber.Options(
		features = "src/test/resource/", 
		tags={"@getBankByBLZCode"},
		format = {"pretty", "html:build/Cucumber -report", "json:build/Cucumber -json-report.json"}
		)

public class TestRunner {

}
