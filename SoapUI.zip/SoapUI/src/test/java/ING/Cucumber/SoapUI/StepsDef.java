package ING.Cucumber.SoapUI;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

import com.eviware.soapui.impl.wsdl.WsdlProject;
import com.eviware.soapui.model.support.PropertiesMap;
import com.eviware.soapui.model.testsuite.TestCase;
import com.eviware.soapui.model.testsuite.TestRunner;
import com.eviware.soapui.model.testsuite.TestSuite;
import com.eviware.soapui.tools.SoapUITestCaseRunner;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class StepsDef {

	    private Hashtable<String, String> codesAndCities;

	    private int failureCount =0, totalCount= 0;

	    private StringBuffer codes = new StringBuffer();

	    @Given("^I have a list of BLZ codes$")
	    public void i_have_a_list_of_BLZ_codes() throws Throwable {
	        // Write code here that turns the phrase above into concrete actions

	        codesAndCities = new Hashtable<>();

	        codesAndCities.put("50021000", "Frankfurt am Main");
	        codesAndCities.put("39020000", "Aachen");

	    }

	    @When("^I use the bank service to get the detail information$")
	    public void i_use_the_bank_service_to_get_the_detail_information() throws Throwable {
	        // Write code here that turns the phrase above into concrete actions
	        Set<Entry<String, String>> set = codesAndCities.entrySet();
	        Iterator<Entry<String, String>> iterator = set.iterator();

	        while (iterator.hasNext()) {
	            Entry<String, String> entry = iterator.next();
	            String blzCode = entry.getKey();
	            String city = entry.getValue();
	            String[] prop ={"blzCode="+blzCode, "city="+city};

	            try {
	                WsdlProject project = new WsdlProject("src/test/resources/Bank-soapui-project.xml");
	                TestSuite testSuite = project.getTestSuiteByName( "TestSuite 1" );
	                TestCase testCase = testSuite.getTestCaseByName( "TestCase 1" );
	                testCase.setPropertyValue("blzCode",blzCode);
	                testCase.setPropertyValue("city",city);
	                testCase.run(new PropertiesMap(), false);

	            } catch (Exception e) {

	                System.err.println("checking " + blzCode + " failed!");

	                failureCount++;

	                codes.append(blzCode + " [" + city +"] ");

	                e.printStackTrace();

	            }finally{

	                totalCount++;

	            }

	        }
	    }

	    @Then("^The information should be found successfully$")
	    public void the_information_should_be_found_successfully() throws Throwable {
	        // Write code here that turns the phrase above into concrete actions

	    }
	
}